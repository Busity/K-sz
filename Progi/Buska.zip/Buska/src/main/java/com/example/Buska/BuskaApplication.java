package com.example.Buska;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BuskaApplication {

	public static void main(String[] args) {
		SpringApplication.run(BuskaApplication.class, args);
	}

}
